// Project identifier: AD48FB4835AF347EB0CA8009E24C3B13F8519882
// Programmer: Qiaozhi Huang
// Date: Feb 2023
// Purpose: implement enum class for movie watcher mode for EECS403 Project2.
#ifndef _STATE_H_
#define _STATE_H_
#include <iostream>
using namespace std;
enum class state{
    Initial, SeenOne, SeenBoth, Maybe
};

#endif