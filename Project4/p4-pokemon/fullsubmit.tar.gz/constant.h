// Project Identifier: 5949F553E20B650AB0FB2266D3C0822B13D248B0
#ifndef CONSTANT_H_
#define CONSTANT_H_
#include <string>
using namespace std;

const char MST = 'M';
const char FAST_TSP = 'F';
const char OPT_TSP = 'O';


#endif